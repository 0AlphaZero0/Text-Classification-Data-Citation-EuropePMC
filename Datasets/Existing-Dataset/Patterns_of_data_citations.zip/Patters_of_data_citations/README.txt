Index to datasets:

Each entry below links a table or figure to a specific data set.  Definition of the data fields is given along with a short STATA do file.

Table_1_accession_pmcids_2014_v32.txt

90,639 obs

This data set includes all of the accessions text-mined from EPMC articles published in 2014

Data fields:  PMC_ID (PMC article accession) DB_NAME (repository) ACCESSION(repository accession)

Basic STATA code:
tabulate DB_NAME

Table_2_PDB_acc_cites

97,332 obs 

Data fields: PDB_ID (PDB source article PMID)  PDB_CITATION_YEAR (Year in which PDB accession was cited in EPMC) COUNT (number of times the accession was cited during that year)

Basic STATA code:
use PDB_source_file
sort PDB_ID
by PDB_ID:  gen dup = cond(_N==1,0,_n)
drop if dup>=2
merge 1:m PDB_ID using PDB_acc_cites
keep if _merge==3
drop if PDB_CITATION_YEAR<=2004
drop if PDB_CITATION_YEAR>=2015  
drop if RELEASE_YEAR<=2004
drop if RELEASE_YEAR>=2015
tabulate   RELEASE_YEAR  PDB_CITATION_YEAR [freq=COUNT]

Table_3_PDB_source_file

207,012 obs

This data set contains details of PDB source articles and their subsequent citation as assessed by text mining the corresponding article citations in EPMC.

PDB_ID (PDB accession) RELEASE_DATE (date PDB entry made public) PUBMED_ID (PMID for source article in PubMed)  PDB_PUBLICATION_YEAR  (date source article published) CITATION_YEAR (year in which source article cited) CITED_COUNT (number of times source article cited during citation year)

Basic STATA code:
tabulate PDB_PUBLICATION_YEAR  CITATION_YEAR [freq=CITED_COUNT]


Table_4_Patents2010_2014_v2 (Also Figure 1)

This dataset contains metadata from SureChEMBL patents published  between 2010-2014.  Only the 2014 component is used here.  The full data set can be used to generate Figure 1.

117,115 obs

pat_id (patent accession)  accession (repository accession) count (number of times accession is cited) dbase (repository) year (year of publication)

Basic STATA code:
use patent_2014
gen index=1
sort DBASE PATENT_ID
by DBASE PATENT_ID:  gen dup = cond(_N==1,0,_n)
drop if dup>=2
tabstat index , s(sum) by(DBASE)

Supp_Table_1_cite_v2

This dataset combines with the next to show ENA accession citation rates over time.

295,990 obs

ena_accession (ENA accession) ena_citation_year (year in which accession was cited in EPMC) DATA_CITATIONS (number of times accession was cited in a given year)

Supp_Table_1_pub_v2

251,037 obs

ena_accession (ENA accession) deposition_date (date data deposited) first_public_date (date data released to public) PMID (source article PMID) SOURCE_PMID_PUBLICATION_YEAR (date source PMID published)

Basic STATA code:
use pub_v2
gen deposition_year_2 = substr(deposition_date,1,9)
gen deposition_year = year(date(deposition_year_2, "DMY", 2015))
gen first_public_year_2 = substr(first_public_date,1,9)
gen first_public_year = year(date(first_public_year_2, "DMY", 2015))
drop deposition_year_2 deposition_date first_public_date first_public_year_2
drop if source_pmid_publication_year<=2004 
drop if deposition_year<=2004
rename  source_pmid_publication_year publication_year
merge 1:m ena_accession using cite_v2
drop if ena_citation_year<=2004
keep if _merge==3
replace data_citations = data_citations-1 if publication_year==ena_citation_year &  data_citations>=1
tabulate first_public_year ena_citation_year  [freq=data_citations]


Supp_Table_2_ena_source_cit_dates_v2

This dataset contains the corresponding statistics regarding source article citation in EPMC.

1,820,399 obs

Pmid (source article PMID)	citation_year (date article cited in EPMC) source_publication_citations  (number of times cited in a given year) pmid_year (year of publication)
